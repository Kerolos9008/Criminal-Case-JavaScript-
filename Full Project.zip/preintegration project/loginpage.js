var userid = 0;
var user = function (username, useremail, userage) {
    userid++;
    this.userid = userid;
    this.username = username;
    this.useremail = useremail;
    this.userage = userage;
    this.charsrc = character;
}

var users = function () {
    this.arruser = [];
    this.adduser = function (userobj) {
        this.arruser.push(userobj);
    }
}
var myusers = new users();


function thelogin() {
    if (txtinput[0].value == "" || ! isNaN(txtinput[0].value)) {
        alertpargh[0].style.display = 'block';
    }
    else if (txtinput[1].value == ""|| isNaN(txtinput[1].value) ) {
        alertpargh[1].style.display = 'block';
        alertpargh[0].style.display = 'none';
        alertpargh[2].style.display = 'none';
    }
    else if (txtinput[2].value == "" )
    {
        alertpargh[2].style.display = 'block';
        alertpargh[0].style.display = 'none';
        alertpargh[1].style.display = 'none';
    }
    else if (txtinput[2].value.indexOf('@') == -1) {
        alertpargh[2].style.display = 'block';
        alertpargh[0].style.display = 'none';
        alertpargh[1].style.display = 'none';
    }
    else if (character == 0) {
        document.getElementById('p2toch').style.color = 'red';
        document.getElementById('p2toch').textContent = 'Please Choose an Officer';
    }
    else // function of confirm button "ya kerolosya :*"
    {
        var holder = new user(txtinput[0].value, txtinput[1].value, txtinput[2].value);
        holder.charsrc = character;
        myusers.adduser(holder);
        alertpargh[0].style.display = 'none';
        alertpargh[1].style.display = 'none';
        alertpargh[2].style.display = 'none';
        document.getElementById('p2toch').style.color = 'goldenrod';
        document.getElementById('p2toch').textContent = 'Select an Officer';
        console.log(checkChar);
        p3checkChar(character);
        page2.style.display = "none";
        page3.style.display = "block";
        loopHistory();
    }

}


var loginbtn = document.getElementById('p2Confirm');
var alertpargh = document.getElementsByClassName('p2theparghforlogin');
var txtinput = document.getElementsByClassName('p2text');
var char1 = document.getElementById('char1');
var char2 = document.getElementById('char2');
var char3 = document.getElementById('char3');

function choosechar1() {
    character = 1;
    char1.style.transform = "scale(1.2)";
    char2.style.transform = "scale(1)";
    char3.style.transform = "scale(1)";
};
function choosechar2() {
    character = 2;
    char2.style.transform = "scale(1.2)";
    char1.style.transform = "scale(1)";
    char3.style.transform = "scale(1)";
};
function choosechar3() {
    character = 3;
    char3.style.transform = "scale(1.2)";
    char1.style.transform = "scale(1)";
    char2.style.transform = "scale(1)";
};

char1.addEventListener('click', choosechar1);
char2.addEventListener('click', choosechar2);
char3.addEventListener('click', choosechar3);
loginbtn.addEventListener('click', thelogin);