
var img1= document.getElementById("p4-vict1");
var img2= document.getElementById("p4-vict2");
var img3= document.getElementById("p4-vict3");

function clck1()
{
    scene=1;
    img1.style.transform = "scale(1.2)";
    img2.style.transform = "scale(1)";
    img3.style.transform = "scale(1)";
}

function clck2()
{
    scene=2;
    img1.style.transform = "scale(1)";
    img2.style.transform = "scale(1.2)";
    img3.style.transform = "scale(1)";
}

function clck3()
{
    scene=3;
    img1.style.transform = "scale(1)";
    img2.style.transform = "scale(1)";
    img3.style.transform = "scale(1.2)";
}

img1.addEventListener('click',clck1);
img2.addEventListener('click',clck2);
img3.addEventListener('click',clck3);