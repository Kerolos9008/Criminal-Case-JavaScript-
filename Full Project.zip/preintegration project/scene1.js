var clue = function (item,box){
    this.item = document.getElementById(item);
    this.box = document.getElementById(box);
    this.found = false;
};
clue.prototype.hide = function(){
    this.item.style.display = "none";
    this.box.style.color = "white";
    this.found = true;
    var finished = true;
    if(sound === 1)
    {
        soundFound.play();
    }
    for(let elem of arr[scene])
    {
        if(elem.found === false)
        {
            finished = false;
        }
    }
    if(finished === true)
    {
        var completed = "s"+scene+"doneImg";
        document.getElementById(completed).style.display = "block";
        if(sound === 1)
        {
            done.play();
        }
        setTimeout(levelCompleted,4000);
    }
}

var hint = function(item,ticket,hintBox){
    this.item = document.getElementById(item);
    this.availableHints = 1;
    this.ticket = document.getElementById(ticket);
    this.hintBox = document.getElementById(hintBox);
};

hint.prototype.stop = function(){
    this.item.onmouseover = function(){
        this.style.cursor = "default";
    };
}

hint.prototype.active = function(){
    this.item.onmouseover = function(){
        this.style.cursor = "pointer";
    };
    this.availableHints=1;
}

hint.prototype.putTicket = function(){
    this.ticket.style.display = "inline-block";
    this.hintBox.style.color = "rgb(167, 167, 60)";
}

hint.prototype.findticket = function(){
    if(this.availableHints===0)
    {
        this.active();
    }
    else
    {
        this.availableHints++;
    }
    this.ticket.style.display = "none";
    this.hintBox.style.color = "white";
}

hint.prototype.activate = function(){
    if(this.availableHints > 0)
    {
        for(var elem of arr[scene])
        {
            if(elem.found === false)
            {
                elem.item.style.transition = "400ms";
                elem.item.style.transform = "scale(1.3)";
                setTimeout(function(){elem.item.style.transform = "scale(1)";},450);
                setTimeout(function(){elem.item.style.transform = "scale(1.3)";},900);
                setTimeout(function(){elem.item.style.transform = "scale(1)";},1350);
                break;
            }
        }        
        this.availableHints--;
        if(this.availableHints === 0)
        {
            this.stop();
        }
    }
}
function levelCompleted()
{
    scene1.style.display="none";
    scene2.style.display="none";
    scene3.style.display="none";
    page5.style.display="block";
    reformLevel();
    id = scene;
    yy = character;
    screen(id);
}

function reformLevel()
{
    for(let elem of arr[scene])
    {
        elem.item.style.display = "inline-block";
        elem.box.style.color = "rgb(167, 167, 60)";
        elem.found = false;
    }
    var completed = "s"+scene+"doneImg";
    document.getElementById(completed).style.display = "none";
    hint1.active();
    hint2.active();
    hint3.active();
    hint1.putTicket();
    hint2.putTicket();
}

var hint1 = new hint("s1hintbtn","s1img5","s1hintTicket");

var arr1 = [new clue("s1img1","s1stethoscope")
,new clue("s1img2","s1plus21")
,new clue("s1img3","s1blackshoes")
,new clue("s1img4","s1injection")];


arr1[0].item.addEventListener("click",function(){arr1[0].hide();});
arr1[1].item.addEventListener("click",function(){arr1[1].hide();});
arr1[2].item.addEventListener("click",function(){arr1[2].hide();});
arr1[3].item.addEventListener("click",function(){arr1[3].hide();});


hint1.item.addEventListener("click",function(){hint1.activate();});
hint1.ticket.addEventListener("click",function(){hint1.findticket();});