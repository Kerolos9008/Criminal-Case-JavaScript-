scene=0;
character=0;
sound = 1;

var page1 = document.getElementById("p1-bgimg-1");
var page2 = document.getElementById("p2mypage");
var page3 = document.getElementById("p3-feature");
var page4 = document.getElementById("p4-lvlspg");
var scene1 = document.getElementById("s1game");
var scene2 = document.getElementById("s2game");
var scene3 = document.getElementById("s3game");
var page5 = document.getElementById("p5_feature");

var p2confirm = document.getElementById("p2Confirm");
var p2back = document.getElementById("p2back");
var p1Play = document.getElementById("p1-Play");
var p3back = document.getElementById("p3-backInp");
var p3ready = document.getElementById("p3-readyInp");
var p4start = document.getElementById("p4-start");
var p4back = document.getElementById("p4-back");
var s1home = document.getElementById("s1home");
var s2home = document.getElementById("s2home");
var s3home = document.getElementById("s3home");
var music = document.getElementById("intro");
var glassBreak = document.getElementById("break");
var soundFound = document.getElementById("found");
var done = document.getElementById("completed");
var s1soundBtn = document.getElementById("s1sound");
var s2soundBtn = document.getElementById("s2sound");
var s3soundBtn = document.getElementById("s3sound");
var p2soundBtn = document.getElementById("p2sound");
var p4soundBtn = document.getElementById("p4sound");


function soundOnOff()
{
    if(sound === 1)
    {
        sound=0;
        music.pause();
    }
    else
    {
        sound=1;
        music.play();
    }
}
function GoToGame()
{
    if(sound === 1)
    {
        glassBreak.play();
    }
    setTimeout(function(){Crash.style.display = "block";},580);
    setTimeout(function (){page1.style.display="none";
                         page2.style.display="block";
                         Crash.style.display="none";
                         if(sound===1)
                         {
                            music.play();
                         }},3000);
}

function GoToScene()
{
    if(scene===0)
    {

    }
    else if(scene===1)
    {
        page4.style.display="none";
        scene1.style.display="block";
    }
    else if (scene===2)
    {
        page4.style.display="none";
        scene2.style.display="block";
    }
    else
    {
        page4.style.display="none";
        scene3.style.display="block";
    }
    music.play();
}

p1Play.addEventListener("click",GoToGame);

p2back.addEventListener("click",function(){page2.style.display="none";
                                           page1.style.display="block";
                                           music.pause();});
p3ready.addEventListener("click",function(){page3.style.display="none";
                                            page4.style.display="block";});
p3back.addEventListener("click",function(){page3.style.display="none";
                                           page2.style.display="block";});
p4back.addEventListener("click",function(){page4.style.display="none";
                                           page3.style.display="block";});
p4start.addEventListener("click",GoToScene);
s1home.addEventListener("click",function(){scene1.style.display="none";
                                           page4.style.display="block";
                                           reformLevel();});
s2home.addEventListener("click",function(){scene2.style.display="none";
                                           page4.style.display="block";
                                           reformLevel();});
s3home.addEventListener("click",function(){scene3.style.display="none";
                                           page4.style.display="block";
                                           reformLevel();});
s1soundBtn.addEventListener("click",soundOnOff);
s2soundBtn.addEventListener("click",soundOnOff);
s3soundBtn.addEventListener("click",soundOnOff);
p2soundBtn.addEventListener("click",soundOnOff);
p4soundBtn.addEventListener("click",soundOnOff);