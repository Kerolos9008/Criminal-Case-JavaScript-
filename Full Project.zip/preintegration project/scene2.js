var hint2 = new hint("s2hintbtn","s2img4","s2hintTicket");

var arr2 = [new clue("s2img1","s2camera")
,new clue("s2img2","s2cd")
,new clue("s2img3","s2china")
,new clue("s2img5","s2mouse")];


arr2[0].item.addEventListener("click",function(){arr2[0].hide();});
arr2[1].item.addEventListener("click",function(){arr2[1].hide();});
arr2[2].item.addEventListener("click",function(){arr2[2].hide();});
arr2[3].item.addEventListener("click",function(){arr2[3].hide();});


hint2.item.addEventListener("click",function(){hint2.activate();});
hint2.ticket.addEventListener("click",function(){hint2.findticket();});