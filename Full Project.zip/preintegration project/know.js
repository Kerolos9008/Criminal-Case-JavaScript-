var timerViewHistory=1,
    historyPara=document.getElementById("p3-history"),
    p3avatar=document.getElementById("p3-img");
    
    
function loopHistory() {
  var history = "The  crime has been increasing and the criminals are free there , please help us collect the evidence to find out the killer , first choose the victim , collect the clues by clicking on them  and at the end determine the killer.<br> p.s : There is a hint in each level you can use it to find out a clue you can have another hint by finding the hint ticket. ";
  if (timerViewHistory<=history.length ) {
    var txt = history.substring(0,timerViewHistory);
    historyPara.innerHTML = txt;
    if (timerViewHistory%2===0) {
      historyPara.style.color="blue"
    } 
    setTimeout('loopHistory()',100);
    timerViewHistory++;
  }
}

function p3checkChar(char) {
  if(char==1){
      p3avatar.src="1.png";
  }else if(char==2){
      p3avatar.src="2.png";
  }else if(char==3){
      p3avatar.src="3.png";
  }
}