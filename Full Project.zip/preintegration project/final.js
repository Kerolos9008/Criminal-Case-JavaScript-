var textPop=document.querySelector("div.p5_imgcontainer h4"),
    btnPopLeft=document.querySelector("div.p5_container input.p5_try"),
    btnPopRigth=document.getElementById("p5_help"),
    ImageList1=document.querySelectorAll("div#p5_features1 div.p5_feat img"),
    ImageList2=document.querySelectorAll("div#p5_features2 div.p5_feat img"),
    ImageList3=document.querySelectorAll("div#p5_features3 div.p5_feat img"),
    avatar=document.querySelector('#p5_avatar');
   // id=1,yy=2;
   

var criminalScreen=function(id,nameDisplay,styleDispaly,
    nameNone,styleNone,nameNone2,styleNone2){
    this.nameDisplay=nameDisplay;
    this.nameNone=nameNone;
    this.nameNone2=nameNone2;
    this.id=id;
    this.block=function(){
        document.getElementById(this.nameDisplay).style.display=styleDispaly;
    };
    this.None=function(){
        document.getElementById(this.nameNone).style.display=styleNone;
        document.getElementById(this.nameNone2).style.display=styleNone2;

    }
}
var styleFeatureGeneral=function(){
  this.setStyleFilter=function(feature,style){
     document.getElementById(feature).style.filter=style;
  }
  this.setStyleDisplay=function(feature,style){
    document.getElementById(feature).style.display=style;
 }
}
var styleFeature=new styleFeatureGeneral();
//main function of 3 screen
function screen(id) {
    styleFeature.setStyleDisplay("p5_guide1","none");
    styleFeature.setStyleDisplay("p5_guide2","none");
    styleFeature.setStyleDisplay("p5_guide3","none");
    reset();
    if(id==1){
        newScreen=new criminalScreen(id,"p5_features1","block",
        "p5_features2","none","p5_features3","none");
        checkClickImage(id);
        checkChar(yy);
    }else if(id==2){
        newScreen=new criminalScreen(id,"p5_features2","block",
        "p5_features1","none","p5_features3","none");
        checkClickImage(id);
        checkChar(yy);
    }else if(id==3){
        newScreen=new criminalScreen(id,"p5_features3","block",
        "p5_features2","none","p5_features1","none");
        checkClickImage(id);
        checkChar(yy);
    }
    newScreen.block();
    newScreen.None();
}
function correct() {
    textPop.textContent="Congratulation,You have a new Badge";
    btnPopLeft.value="Continue";
    btnPopRigth.value="Exit";
}
function reset() {
    textPop.textContent="Try again,can you use help?";
    btnPopLeft.value="Try again";
    btnPopRigth.value="Show Answer";
    noDisplayBadge();
}
function noDisplayBadge(){
    styleFeature.setStyleDisplay("p5badge1","none");
    styleFeature.setStyleDisplay("p5badge2","none");
    styleFeature.setStyleDisplay("p5badge3","none");
}
function btnClickImage(id) {
    for(i=0;i<ImageList1.length;i++){ 
       if(ImageList1[i]==document.getElementById("p5_imgP"+id)){
        styleFeature.setStyleDisplay("p5_modal-wrapper","block");
        styleFeature.setStyleDisplay("p5_feature","none");
        styleFeature.setStyleFilter("p5_feature","grayscale(100%)");
        if(i==0){
          x=1;
        }else if(i==1){
          x=2;
        }
        else if(i==2){
          x=3;
        }
       }
    }
}

function checkClickImage(id){
    if(id==1){
        ImageList1[0].addEventListener("click",function(){
            btnClickImage(1)
        })
        ImageList1[1].addEventListener("click",function(){
            correct();
            styleFeature.setStyleDisplay("p5badge3","block");
            btnClickImage(2);
        })
        ImageList1[2].addEventListener("click",function(){
            btnClickImage(3)
        })
    }else if(id==2){
        ImageList2[0].addEventListener("click",function(){
            btnClickImage(1)
        })
        ImageList2[1].addEventListener("click",function(){
            btnClickImage(2)
        })
        ImageList2[2].addEventListener("click",function(){
            btnClickImage(3);
            correct();
            styleFeature.setStyleDisplay("p5badge2","block");

        })
    }else if(id==3){
        ImageList3[0].addEventListener("click",function(){
            correct();
            btnClickImage(1);
            styleFeature.setStyleDisplay("p5badge1","block");

        })
        ImageList3[1].addEventListener("click",function(){
            btnClickImage(2)
        })
        ImageList3[2].addEventListener("click",function(){
            btnClickImage(3);
        })
    }
}

btnPopRigth.addEventListener("click",function(){
    styleFeature.setStyleDisplay("p5_modal-wrapper","none");
    document.getElementById("p5_feature").setAttribute("style","blur(10px) saturate(1.5)");
    guideAnswer(id)
})
function guideAnswer(id) {
    styleFeature.setStyleDisplay("p5_feature","block");
   if(id==1){
        if(x==1||x==3){
            styleFeature.setStyleDisplay("p5_guide2","block");
        }else if(x==2){
            window.close();
        }
   }else if(id==2){
        if(x==1||x==2){
            styleFeature.setStyleDisplay("p5_guide3","block");
        }else if(x==3){
            window.close();
        }
   }else if(id==3){
        if(x==1){
            window.close();
        }else if(x==2||x==3){
            styleFeature.setStyleDisplay("p5_guide1","block");
        }
    }
}
btnPopLeft.addEventListener("click",function(){
    styleFeature.setStyleDisplay("p5_modal-wrapper","none");
    document.getElementById("p5_feature").setAttribute("style","blur(10px) saturate(1.5)")
     cont(id);
})
function cont(id) {
    if (id==1) {
        if(x==1||x==3){
            styleFeature.setStyleDisplay("p5_feature","block");
        }
        else if(x==2){
            styleFeature.setStyleDisplay("p5_feature","none");
            styleFeature.setStyleDisplay("p4-lvlspg","block");
            reset();
        }
    } else if(id==2) {
        if(x==1||x==2){
            styleFeature.setStyleDisplay("p5_feature","block");
        }
        else if(x==3){
            styleFeature.setStyleDisplay("p5_feature","none");
            styleFeature.setStyleDisplay("p4-lvlspg","block");
            reset();
        }
    }else if(id==3){
        if(x==2||x==3){
            styleFeature.setStyleDisplay("p5_feature","block");
        }
        else if(x==1){
            styleFeature.setStyleDisplay("p5_feature","none");
            styleFeature.setStyleDisplay("p4-lvlspg","block");
            reset();
        }
    }
}
function checkChar(char) {
    if(char==1){
        avatar.src="1.png"
    }else if(char==2){
        avatar.src="2.png"
    }else if(char==3){
        avatar.src="3.png"
    }
}
