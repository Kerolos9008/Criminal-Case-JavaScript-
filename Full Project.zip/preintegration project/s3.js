var hint3 = new hint("s3hintbtn","");

var arr3 = [new clue("s3img7","s3bag")
,new clue("s3img3","s3book")
,new clue("s3img1","s3glass")
,new clue("s3img6","s3lap")
,new clue("s3img2","s3saw")
,new clue("s3img5","s3hand")
,new clue("s3img4","s3cap")];

arr3[0].item.addEventListener("click",function(){arr3[0].hide();});
arr3[1].item.addEventListener("click",function(){arr3[1].hide();});
arr3[2].item.addEventListener("click",function(){arr3[2].hide();});
arr3[3].item.addEventListener("click",function(){arr3[3].hide();});
arr3[4].item.addEventListener("click",function(){arr3[4].hide();});
arr3[5].item.addEventListener("click",function(){arr3[5].hide();});
arr3[6].item.addEventListener("click",function(){arr3[6].hide();});

hint3.item.addEventListener("click",function(){hint3.activate();});

arr = [];
arr[1] = arr1;
arr[2] = arr2;
arr[3] = arr3;