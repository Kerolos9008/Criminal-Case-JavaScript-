var Badges = document.getElementById("p1-Badges");
var Credits = document.getElementById("p1-Credits");
var Crash = document.getElementById("p1-crash");
var CreditsWindow = document.getElementById("p1-Credits-Window");
var BadgesWindow = document.getElementById("p1-Badges-Window");
var span = document.getElementsByClassName("p1-close");

function DisplayCredits()
{
  CreditsWindow.style.display = "block";
}
function DisplayBadges()
{
  BadgesWindow.style.display = "block";
}
function HideCredits()
{
  CreditsWindow.style.display = "none";
}
function HideBadges()
{
  BadgesWindow.style.display = "none";
}

Credits.addEventListener("click",DisplayCredits);
Badges.addEventListener("click",DisplayBadges);
span[0].addEventListener("click",HideCredits);
span[1].addEventListener("click",HideBadges);

